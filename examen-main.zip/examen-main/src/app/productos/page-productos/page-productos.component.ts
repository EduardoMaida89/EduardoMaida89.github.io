import { Component } from '@angular/core';

@Component({
  selector: 'app-page-productos',
  templateUrl: './page-productos.component.html',
  styleUrls: ['./page-productos.component.css']
})
export class PageProductosComponent {

}
