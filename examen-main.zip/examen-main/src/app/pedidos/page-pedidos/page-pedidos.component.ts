import { Component } from '@angular/core';

@Component({
  selector: 'app-page-pedidos',
  templateUrl: './page-pedidos.component.html',
  styleUrls: ['./page-pedidos.component.css']
})
export class PagePedidosComponent {

}
